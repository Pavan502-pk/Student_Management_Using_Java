import java.calendar.*;
class dates
{
public static void main(String ar[ ])
{
Date year=new Date();
System.out.println("year="+year.getDate());
}
}